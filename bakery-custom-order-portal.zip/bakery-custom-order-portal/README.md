# Bakery Custom Order Portal

A full-stack bakery ordering website: browse products, build a custom cake, place a cash-on-delivery / pay-on-pickup order, track it, and manage everything from a protected admin dashboard.

**Stack:** HTML5 · CSS3 · Vanilla JavaScript · Node.js · Express · MongoDB Atlas (Mongoose)
**Hosting plan:** Vercel (frontend) · Render (backend) · MongoDB Atlas (database)

> Status: Phase 1 complete (project structure and configuration). This README is expanded in Phase 8.
